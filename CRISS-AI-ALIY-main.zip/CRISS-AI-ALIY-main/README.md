     𝗖𝗥𝗜𝗦𝗦 𝗔𝗜 𝗣𝗢𝗪𝗘𝗥𝗙𝗨𝗟 𝗪𝗛𝗔𝗧𝗦𝗔𝗣𝗣 𝗕𝗢𝗧
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

<p align="center">
  <a href="https://github.com/criss-vevo">
    <img alt="criss-vevo logo"  src="https://files.catbox.moe/j67u2n.jpg">
  </a>
</p>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>


#### SETUP 


<p align="left">
<a href="https://github.com/criss-vevo/CRISS-AI/fork"><img src="https://img.shields.io/badge/Fork-white" alt="𝐅𝐨𝐫𝐤" width="100"></a>


<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>



 <p align="left">
<a href="https://criss-vevo-a58c8cd81fc9.herokuapp.com"><img src="https://img.shields.io/badge/Get%20Session%20-white" alt=" 𝐬𝐞𝐬𝐬𝐢𝐨𝐧 02" width="200"></a>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>


<p align="left">
<a href="https://criss-ai.vercel.app" target="_blank"><img title="DEPLOY-ON HEROKU" src="https://img.shields.io/badge/DEPLOY%20ON%20HEROKU-white"" alt="Heroku" width="300"></a>
</p>
  
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

<p align="left">
<a href="https://deploy-on-render-alpha.vercel.app" target="_blank"><img title="DEPLOY-ON RENDER" src="https://img.shields.io/badge/DEPLOY%20ON%20RENDER-white" alt="Heroku" width="300"></a>
</p>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

<div align="left">
  <a href="https://whatsapp.com/channel/0029VbAhCy8EquiTSb5pMS3t">
    <img src="https://img.shields.io/badge/Join-WhatsApp%20Channel-25D366?style=for-the-badge&logo=whatsapp&logoColor=white&labelColor=000000" width="330"></a>
  </a>
</div>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>


<p>&nbsp;<img align="center" src="https://github-readme-stats.vercel.app/api?username=criss-vevo&show_icons=true&locale=en" alt="criss-vevo" /></p>

<p><img align="center" src="https://github-readme-streak-stats.herokuapp.com/?user=criss-vevo&" alt="criss-vevo" /></p>

